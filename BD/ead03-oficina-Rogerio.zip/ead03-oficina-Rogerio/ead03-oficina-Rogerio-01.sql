INSERT INTO `clientes`(`nome`,`cpf`,`telefone`,`cidade`,`uf`,`endereco`,`bairro`,`cep`)
VALUE ('Rogério Silva','00012345699','32987654321','Descoberto','MG','Rua Tenente Furtadinho,77','Centro','36690000');
INSERT INTO `clientes`(`nome`,`cpf`,`telefone`,`cidade`,`uf`,`endereco`,`bairro`,`cep`)
VALUE ('Camyle Alves','12345678900','32985662233','Descoberto','MG','Rua Das Flores,56','Centro','36690000');
INSERT INTO `clientes`(`nome`,`cpf`,`telefone`,`cidade`,`uf`,`endereco`,`bairro`,`cep`)
VALUE ('Hadson Nepomuceno','55566644477','32986775698','São João Nepomuceno','MG','Rua Das Pedras,34','Centenario','36680000');
INSERT INTO `clientes`(`nome`,`cpf`,`telefone`,`cidade`,`uf`,`endereco`,`bairro`,`cep`)
VALUE ('Wilian Lemos','78945612368','32987264815','São João Nepomuceno','MG','Rua Cap.Bráz,15','Santa Rita','36680000');
INSERT INTO `clientes`(`nome`,`cpf`,`telefone`,`cidade`,`uf`,`endereco`,`bairro`,`cep`)
VALUE ('Pedro Oliveira','36925814714','329899847932','São João Nepomuceno','MG','Rua Cap.Bráz,25','Santa Rita','36680000');

SELECT * FROM `clientes`;