INSERT INTO `mecanicos`(`nome`,`cpf`,`telefone`,`cidade`,`uf`,`endereco`,`bairro`,`cep`)
VALUE ('José Pinheiro','35768942155','32999988663','Descoberto','MG','Rua Frederico Bressan,108','Centro','36690000');
INSERT INTO `mecanicos`(`nome`,`cpf`,`telefone`,`cidade`,`uf`,`endereco`,`bairro`,`cep`)
VALUE ('Gilberto Ferreira','99987545399','32999746974','São João Nepomuceno','MG','Rua Cap.Bráz,108','Centro','36680000');

SELECT * FROM `mecanicos`;