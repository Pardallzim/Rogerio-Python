INSERT INTO `carros`(`marca`,`modelo`,`placa`,`clientes_idclientes`)
VALUE ('Volkswagen','Gol','ABC1234',5);
INSERT INTO `carros`(`marca`,`modelo`,`placa`,`clientes_idclientes`)
VALUE ('Toyota ','Corolla','HFR3012',2);
INSERT INTO `carros`(`marca`,`modelo`,`placa`,`clientes_idclientes`)
VALUE ('Fiat ','Mobi','KJO8956',4);
INSERT INTO `carros`(`marca`,`modelo`,`placa`,`clientes_idclientes`)
VALUE ('Hyundai ','HB20','BCW6245',1);
INSERT INTO `carros`(`marca`,`modelo`,`placa`,`clientes_idclientes`)
VALUE ('Volkswagen','Voyage','FQG3564',3);

SELECT * FROM `carros`;