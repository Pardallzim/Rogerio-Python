INSERT INTO `ordem`(`carros_idcarros`,`mecanicos_idmecanicos`,`defeito`,`valor`,`desconto`)
VALUE (1,2,'Motor',3000.00,200.00);
INSERT INTO `ordem`(`carros_idcarros`,`mecanicos_idmecanicos`,`defeito`,`valor`,`desconto`)
VALUE (4,1,'Correia dentada',4000.00,100.00);
INSERT INTO `ordem`(`carros_idcarros`,`mecanicos_idmecanicos`,`defeito`,`valor`,`desconto`)
VALUE (5,1,'Cabeçote',3000.00,150.00);
INSERT INTO `ordem`(`carros_idcarros`,`mecanicos_idmecanicos`,`defeito`,`valor`)
VALUE (2,1,'Tanque Furado',1000.00);
INSERT INTO `ordem`(`carros_idcarros`,`mecanicos_idmecanicos`,`defeito`,`valor`,`desconto`)
VALUE (3,2,'Correia dentada',4000.00,200.00);

SELECT * FROM `ordem`;